package com.example.mainmenu.Users;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mainmenu.CreateDialog;
import com.example.mainmenu.JoinDialog;
import com.example.mainmenu.R;


public class Menu extends AppCompatActivity {

    private Button join;
    private Button create;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);

        Intent intent = getIntent();

        String user = intent.getStringExtra("user");

        TextView usertext = findViewById(R.id.usertext);

        usertext.setText(user);

        this.join = (Button) findViewById(R.id.join);
        this.create = (Button) findViewById(R.id.create);

        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPopupJoin();
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPopupCreate();
            }
        });

    }


    public void openPopupJoin() {
        JoinDialog joinDialog = new JoinDialog();
        joinDialog.show(getSupportFragmentManager(), "join");
    }

    public void openPopupCreate() {
        CreateDialog createDialog = new CreateDialog();
        createDialog.show(getSupportFragmentManager(), "create");
    }

}
