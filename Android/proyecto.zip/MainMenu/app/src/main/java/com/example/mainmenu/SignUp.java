package com.example.mainmenu;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignUp extends AppCompatActivity {

    public String userst,usernamest,userpassst;
    DBAdapter db;
    Button remove;
    Button ok;
    TextView username,usersurname,userpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        Context context;

        this.remove = findViewById(R.id.remove);
        this.ok = findViewById(R.id.ok);
        this.username = findViewById(R.id.username);
        this.usersurname = findViewById(R.id.usersurname);
        this.userpass = findViewById(R.id.userpass);

        //Clears all boxes

        remove.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                username.setText("");
                usersurname.setText("");
                userpass.setText("");
            }
        });


        //Gets all boxes info to the strings to be used on another activity

        final Context finalContext = null;
        ok.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

               userst = username.getText().toString();
               usernamest = username.getText().toString();
               userpassst = userpass.getText().toString();

               if (userst.isEmpty() || usernamest.isEmpty() || userpassst.isEmpty()){
                    openErrorDialog();
               }
               else{

                   db.insertData( "testing", "tespass");



                   openPopupAsk();

               }
            }
        });
    }

    public void openPopupAsk() {
        AskDialog ad = new AskDialog();
        ad.show(getSupportFragmentManager(), "");
    }
    public void openErrorDialog() {
        ErrorDialog ed = new ErrorDialog();
        ed.show(getSupportFragmentManager(), "");
    }

}
