package com.example.mainmenu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

import com.example.mainmenu.Users.Menu;
import com.example.mainmenu.Users.Users;
import com.example.mainmenu.interfaz.jasonapi;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {


    Button singup;
    Button login;
    EditText email;
    EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getUser();

        this.login = (Button) findViewById(R.id.login);
        this.singup = (Button) findViewById(R.id.signup);
        this.email = (EditText) findViewById(R.id.emailtext);
        this.pass = (EditText) findViewById(R.id.passtext);

        login.setEnabled(true);
        singup.setEnabled(true);

        login.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                openActivityLogin();
            }
        });

        singup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignup();
            }
        });


    }

    public final static String TAG=null;
    private void getUser(){
        Retrofit retrofit= new Retrofit.Builder()
                .baseUrl("http://localhost:8080/alcoholimpiadas/webresources/users/getalluser/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        jasonapi json = retrofit.create(jasonapi.class);

        Call<List<Users>> call = json.getUsers();


        call.enqueue(new Callback<List<Users>>() {
            @Override
            public void onResponse(Call<List<Users>> call, Response<List<Users>> response) {
                if(!response.isSuccessful()){
                    email.setText("errorea gertatudek");

                    return;
                }

                List<Users> usersList = response.body();

                for(Users user: usersList){
                    String content="";
                    content+= "userId:" + user.getUser() + "kk" +user.getPasswd() +"lk"+ user.getId()+"fdf"+ user.getType();
                    Log.e(TAG, "hola"+user.getUser());
                }

            }

            @Override
            public void onFailure(Call<List<Users>> call, Throwable t) {

            }
        });
    }


    public void openActivityLogin(){
        Intent intent = new Intent(this, Menu.class);
        intent.putExtra("user", email.getText().toString());
        startActivity(intent);
    }

    public void openSignup(){
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }


}
