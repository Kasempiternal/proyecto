package com.example.mainmenu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

import com.example.mainmenu.Users.Menu;
import com.example.mainmenu.Users.Users;
import com.example.mainmenu.interfaz.jasonapi;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {
    DBAdapter db;

    Button singup;
    Button login;
    EditText email;
    EditText pass;
    String emailst,passst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBAdapter(this);
        this.login = (Button) findViewById(R.id.login);
        this.singup = (Button) findViewById(R.id.signup);
        this.email = (EditText) findViewById(R.id.emailtext);
        this.pass = (EditText) findViewById(R.id.passtext);

        login.setEnabled(true);
        singup.setEnabled(true);



        login.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                emailst = email.getText().toString();
                passst = pass.getText().toString();
                if (emailst.isEmpty() || passst.isEmpty() ){
                    openErrorDialog();
                }
                else{
                    openActivityLogin();
                }
            }
        });

        singup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignup();

            }
        });


    }

    public void openActivityLogin(){
        Intent intent = new Intent(this, Menu.class);
        intent.putExtra("user", email.getText().toString());
        startActivity(intent);
    }

    public void openSignup(){
        Intent intent = new Intent(this, SignUp.class);
        startActivity(intent);
    }
    public void openErrorDialog() {
        ErrorDialog ed = new ErrorDialog();
        ed.show(getSupportFragmentManager(), "");
    }


}
