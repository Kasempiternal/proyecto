package com.example.mainmenu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    Button singup;
    Button login;
    EditText email;
    EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.login = (Button) findViewById(R.id.login);
        this.singup = (Button) findViewById(R.id.signup);
        this.email = (EditText) findViewById(R.id.emailtext);
        this.pass = (EditText) findViewById(R.id.passtext);


        login.setEnabled(true);
        singup.setEnabled(true);

        login.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                String user =  email.getText().toString();
                String passwd = pass.getText().toString();


            }
        });


    }  public void loginok() {
        Intent intent = new Intent(this, menu.class);
        startActivity(intent);
    }


}
