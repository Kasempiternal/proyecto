package com.example.mainmenu.Users;

public class Users {

    //poner igual que los que salen en la web de jersey

    private int idUser;
    private String name;
    private String pass;
    private int type;

    public int getId() {
        return idUser;
    }

    public String getUser() {
        return name;
    }

    public String getPasswd() {
        return pass;
    }

    public int getType() {
        return type;
    }
}
